<?php 

    $mod_strings['LBL_TEXT_FIELD_ABN_BUSINESS'] = 'ABN';
    
?>